export { default as HomeScreen } from './home'
export { default as DetailScreen } from './detail'
