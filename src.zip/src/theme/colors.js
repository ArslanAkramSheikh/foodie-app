export const colors = {
  primary: '#FFC329',
  secondary: '#FFEFC5',

  white: '#FFFFFF',
  whiteVariant: '#F8F8F8',
  black: '#292D25',
  blackTranslucid: '#292d2514',
  gray: '#C8C8C8',

  red: '#FF626B',
  orange: '#ed6036',
  blue: '#4179e9'
}
