import { colors } from './colors'
import { fonts } from './fonts'

export default theme = {
  colors,
  fonts
}
