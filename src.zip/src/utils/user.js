export const getFirstName = fullName => fullName?.split(' ')[0]
